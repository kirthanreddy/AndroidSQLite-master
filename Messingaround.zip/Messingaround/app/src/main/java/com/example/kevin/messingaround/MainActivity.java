package com.example.kevin.messingaround;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private Button bluetooth_button;
    Button insertButton;
    //EditText inputTextX;
    EditText inputTextY;
    GraphView graphView;
    LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[0]);
    MyHelper myHelper;
    SQLiteDatabase sqLiteDatabase;
    // Real Time
    SimpleDateFormat sdf=new SimpleDateFormat("h:mm:ss a");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetooth_button = (Button) findViewById(R.id.bluetooth_button);
        bluetooth_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openbluetooth();
            }
        });

        insertButton=(Button) findViewById(R.id.insertButton);
        //inputTextX=(EditText) findViewById(R.id.inputTextX);
        inputTextY=(EditText) findViewById(R.id.inputTextY);
        graphView=(GraphView) findViewById(R.id.graph);
        myHelper=new MyHelper(this);
        sqLiteDatabase=myHelper.getWritableDatabase();

        graphView.getViewport().setScalable(true);
        graphView.getViewport().setScalableY(true);

        series.setDrawBackground(true);
        series.setDrawDataPoints(true);
        graphView.getGridLabelRenderer().setHumanRounding(false);
        //graphView.getGridLabelRenderer().setNumHorizontalLabels(3);
        graphView.addSeries(series);

        series.setOnDataPointTapListener(new OnDataPointTapListener() {
            @Override
            public void onTap(Series series, DataPointInterface dataPointInterface) {
                String msg="X: " +dataPointInterface.getX()+"\nY: "+dataPointInterface.getY();
                Toast.makeText(MainActivity.this,msg,Toast.LENGTH_LONG).show();
            }
        });

        graphView.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
            @Override
            public String formatLabel(double value, boolean isValueX) {
                if(isValueX)
                {
                    return sdf.format(new Date((long)value));
                }else {
                    return super.formatLabel(value, isValueX);
                }
            }
        });
        series.resetData(getDataPoint());
        exqInsert();
    }

    public void openbluetooth(){
        Intent intent = new Intent(this,bluetooth.class);
        startActivity(intent);
    }




    private void exqInsert(){
        insertButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                long xValue=new Date().getTime();
                //int xValue=Integer.parseInt(String.valueOf(inputTextX.getText()));
                int yValue=Integer.parseInt(String.valueOf(inputTextY.getText()));

                myHelper.insertData(xValue,yValue);

                series.resetData(getDataPoint());

                // Real Time
                graphView.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter(){
                    @Override
                    public String formatLabel(double value, boolean isValueX) {
                        if(isValueX)
                        {
                            return sdf.format(new Date((long) value));
                        }else {
                            return super.formatLabel(value, isValueX);
                        }
                    }
                });
            }
        });
    }

    private DataPoint[] getDataPoint() {
        String[] columns={"xValues","yValues"};
        Cursor cursor=sqLiteDatabase.query("myTable",columns,null,null,null,null,null);
        DataPoint[] dp=new DataPoint[cursor.getCount()];

        for(int i=0;i<cursor.getCount();i++){
            cursor.moveToNext();
            //dp[i]=new DataPoint(cursor.getInt(0),cursor.getInt(1));
            // Real Time
            dp[i]=new DataPoint(cursor.getLong(0),cursor.getInt(1));
        }
        return dp;
    }
}
